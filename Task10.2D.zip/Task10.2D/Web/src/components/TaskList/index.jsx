import React, { useState, useEffect } from 'react'
import './index.css'
import axios from 'axios';

function TaskModal (props) {
  return (
    <div className="modal">
      <div className="modal-header">
        <div>Detail</div>
        <div onClick={props.closeModal}>x</div>
      </div>
      <div>
        <div>title: {props.currentTask.title}</div>
        <div>task1: {props.currentTask.task1}</div>
        <div>date: {props.currentTask.date}</div>
        <div>master: {props.currentTask.master}</div>
        <div>reward: {props.currentTask.reward}</div>
        <div>number: {props.currentTask.number}</div>
        <div>description: {props.currentTask.description}</div>
      </div>
    </div>
  )
}
function TaskList (props) {
  const [date, setDate] = useState('');
  const [title, setTitle] = useState('');
  const [tableList, setTableList] = useState([]);
  const [isShowModal, setIsShowModal] = useState(false);
  const [currentTask, setCurrentTask] = useState({});

  useEffect(() => {
    axios.get('http://localhost:3001/api/task').then(response => {
      console.log(response);
      if (response.status === 200) {
        setTableList(response.data)
      }
    })
  }, []);

  // search task
  const searchHandler = () => {
    axios.post('http://localhost:3001/api/search_task', { date, title }).then(response => {
      console.log(response);
      if (response.status === 200) {
        setTableList(response.data);
      }
    })
  }

  // delete data
  const deleteRow = (id) => {
    axios.post('http://localhost:3001/api/delete_task', { id }).then(response => {
      if (response.status === 200) {
        alert(response.data.message);
        if (response.data.code == 0) {
          window.location.href = '/';
        }
      }
    })
  }

  const detailsRow = (item) => {
    setCurrentTask(item);
    setIsShowModal(true);
  }

  const closeModal = () => {
    setIsShowModal(false);
  }

  return (
    <div className="task-list">
      <div className="search">
        <input type="text" placeholder="Enter task title" value={title} onChange={(event) => { setTitle(event.target.value) }} className="title-input" />
        <input type="date" value={date} onChange={(event) => setDate(event.target.value)} />
        <button type="button" onClick={searchHandler}>search</button>
      </div>
      <table className="task-table" cellSpacing="0">
        <thead>
          <tr>
            <th>title</th>
            <th>task1</th>
            <th>date</th>
            <th>master</th>
            <th>reward</th>
            <th>number</th>
            <th>description</th>
            <th>taskType</th>
            <th>Operation</th>
          </tr>
        </thead>
        <tbody>
          {
            tableList.map((item, index) => {
              return (
                <tr key={index}>
                  <th>{item.title}</th>
                  <th>{item.task1}</th>
                  <th>{item.date}</th>
                  <th>{item.master}</th>
                  <th>{item.reward}</th>
                  <th>{item.number}</th>
                  <th>{item.description}</th>
                  <th>
                    <img src={item.taskType} style={{ width: '100px', height: '100px' }} />
                  </th>
                  <th>
                    <button onClick={() => detailsRow(item)} style={{ marginRight: '10px' }}>details</button>
                    <button onClick={() => deleteRow(item._id)}>delete</button>
                  </th>
                </tr>
              )
            })
          }
        </tbody>
      </table>
      {
        isShowModal ? <TaskModal currentTask={currentTask} closeModal={closeModal} /> : null
      }

    </div>
  )
}
export default TaskList;
